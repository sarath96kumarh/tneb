import pandas as pd
import numpy as np

def Gear_position(file):
  gear_data=pd.read_csv(file)

  gear_ratio_required_data=gear_data[['GDL','RPM','ANR','TIME','LONG','LAT','ALT','GS']]
  gear_ratio_required_data['GDL']=gear_ratio_required_data['GDL'].astype('str')
  gear_ratio_required_data['RPM']=gear_ratio_required_data['RPM'].astype('str')
  gear_ratio_required_data['ANR']=gear_ratio_required_data['ANR'].astype('str')
  gear_ratio_required_data['TIME']=gear_ratio_required_data['TIME'].astype('str')
  gear_ratio_required_data['LONG']=gear_ratio_required_data['LONG'].astype('str')
  gear_ratio_required_data['LAT']=gear_ratio_required_data['LAT'].astype('str')
  gear_ratio_required_data['GS']=gear_ratio_required_data['GS'].astype('str')




  without_null=gear_ratio_required_data[~gear_ratio_required_data.GDL.isin(['nan'])]
  without_null_2=without_null[~without_null.RPM.isin(['nan'])]
  without_null_2=without_null_2[~without_null_2.ANR.isin(['nan'])]
  without_null_2=without_null_2[~without_null_2.LONG.isin(['nan'])]
  without_null_2=without_null_2[~without_null_2.LAT.isin(['nan'])]
  without_null_2=without_null_2[~without_null_2.GS.isin(['nan'])]

  without_null_2['GDL']=without_null_2['GDL'].astype('float')
  without_null_2['RPM']=without_null_2['RPM'].astype('float')
  without_null_2['RPM']=without_null_2['RPM']*0.93
  without_null_2['ANR']=without_null_2['ANR'].astype('float')
  without_null_2['LONG']=without_null_2['LONG'].astype('float')
  without_null_2['LAT']=without_null_2['LAT'].astype('float')
  without_null_2['GS']=without_null_2['GS'].astype('float')
  
  #Gear ratio 
  without_null_2['gear_ratio']=without_null_2['GDL']/without_null_2['RPM']
  without_null_2['gear_ratio'] = without_null_2['gear_ratio'].round(decimals = 1)
  
  
  #neutral
  without_null_2['gear'] = ['0' if x >15.95 or x<0.9 else 'need' for x in without_null_2['gear_ratio'] ]
  neutral_dataframe=without_null_2[(without_null_2['gear']=='0')]
  neutral_dataframe=neutral_dataframe[['GDL','RPM','ANR','TIME','LONG','LAT','ALT','GS','gear_ratio','gear']]
  #neutral_dataframe.to_csv('neutral.csv')
  

  #other_gears_position
  gear_value=[[15.9,14.5],[14.5,9.4],[9.4,6.6],[6.6,4.8],[4.8,3.6]
            ,[3.6,2.5],[2.5,1.8],[1.8,1.3],[1.3,1]] 
  gear=[['0','1'],['1','2'],['2','3'],['3','4'],['4','5'],['5','6'],['6','7']
      ,['7','8'],['8','9']]

  final_df=pd.DataFrame(columns=['GDL','RPM','ANR','TIME','LONG','LAT','ALT','GS','gear_ratio','gear'])
  for ss in range(0,len(gear_value)):
    first_half_mid_way=[gear_value[ss][0]]
    sec_half_mid_way=[gear_value[ss][1]]
    
    
    #mid_point_finder
    while first_half_mid_way[-1]!=sec_half_mid_way[-1] and sec_half_mid_way[-1]!=round(first_half_mid_way[-1]-.1,1) :
      first_half_mid_way.append(round(first_half_mid_way[-1]-.1,1))
      sec_half_mid_way.append(round(sec_half_mid_way[-1]+.1,1))
      
    filter=without_null_2[(without_null_2['gear_ratio'] >= gear_value[ss][1]) & (without_null_2['gear_ratio'] <=gear_value[ss][0] )]
    filter=filter[['GDL','RPM','ANR','TIME','LONG','LAT','ALT','GS','gear_ratio']]
    filter['gear'] = [gear[ss][0] if x >=first_half_mid_way[-1]  else gear[ss][1] for x in filter['gear_ratio'] ]
    final_df=pd.concat([final_df,filter])
  
  
  #final_df.to_csv('without_neutral.csv')
  save_dataframe_data=pd.concat([neutral_dataframe,final_df],ignore_index=True)
  save_dataframe_data.to_csv('Gears.csv')
  
  
  #RPM range
  rpm_max=save_dataframe_data['RPM'].max()
  rpm_min=save_dataframe_data['RPM'].min()
  rpm_range_list=[[round(rpm_min),round(rpm_min)+150]]
  while rpm_range_list[-1][1]<=rpm_max:
           rpm_range_list.append([rpm_range_list[-1][1]+1,rpm_range_list[-1][1]+1+150])


  #torque range
  torque_max=save_dataframe_data['ANR'].max()
  torque_min=save_dataframe_data['ANR'].min()
  torque_range_list=[[round(torque_min),round(torque_min)+100]]
  while torque_range_list[-1][1]<=torque_max:
           torque_range_list.append([torque_range_list[-1][1]+1,torque_range_list[-1][1]+1+100])


  #range_combination_rpm_tor_gearv
  rpm_tor_comb=[]
  gear_pos=[0,1,2,3,4,5,6,7,8,9,10]

  for ssn in rpm_range_list:
    for ssk in torque_range_list:
      for gg in gear_pos:
        rpm_tor_comb.append([ssn,ssk,gg])
  
  
  #gear_wise_filter
  gear_wise_filter=[]
  append_list=[]

  for qq in gear_pos:
    if append_list:
      gear_wise_filter.append(append_list)
      append_list=[]
    for kkl in rpm_tor_comb:
          if kkl[-1] == qq:
              append_list.append(kkl)
  
  
  #calculation_data
  calculation_data=[]
  con_calculation_data=[]
  
  #function_to_calculated_timeframecount_accros_tor_rpm_gear_&&_formula_cal
  def rotation_calculation(gear_wise_combo):
    gears_to_be_calculated_for=gear_wise_combo[0][-1]
    data_for_gear_to_be_calculated_only=save_dataframe_data[
                                        (save_dataframe_data['gear'] == str(gears_to_be_calculated_for))]
    

    def count_of_time_stamp_inrange(single_data_range):
        ccount=len(data_for_gear_to_be_calculated_only[
                                ((data_for_gear_to_be_calculated_only['RPM']>=single_data_range[0][0])&(data_for_gear_to_be_calculated_only['RPM']<=single_data_range[0][1])) 
                                 & 
                                ((data_for_gear_to_be_calculated_only['ANR']>=single_data_range[1][0])&(data_for_gear_to_be_calculated_only['ANR']<=single_data_range[1][1]))
                     
                                                      ]
                  )
        
        
        rpmss_f=(round((single_data_range[0][0]+single_data_range[0][1])/2)/60)*(ccount*5)
        calculation_data.append([single_data_range[1][0],single_data_range[1][1],single_data_range[0][0],single_data_range[0][1],
                                                gears_to_be_calculated_for,ccount,rpmss_f])

        
        #continous_timeframe
        
                     
                                                      
        if ccount:
            can_data=data_for_gear_to_be_calculated_only[
                                ((data_for_gear_to_be_calculated_only['RPM']>=single_data_range[0][0])&(data_for_gear_to_be_calculated_only['RPM']<=single_data_range[0][1])) 
                                 & 
                                ((data_for_gear_to_be_calculated_only['ANR']>=single_data_range[1][0])&(data_for_gear_to_be_calculated_only['ANR']<=single_data_range[1][1]))           
                                                         ]
            can_data.reset_index(inplace=True)    
                           
            count_end_index=1
            start=int(str(can_data['TIME'].iloc[0]).split(':')[0])
            print('hellloo',can_data['TIME'].head(8))
            print(start)
            start_index=0
            

            for tim in can_data['TIME'].loc[1:]:
                print('out',start+1,start,int(str(tim).split(':')[0]))
                if start+1==int(str(tim).split(':')[0]) or start==int(str(tim).split(':')[0]):
                    count_end_index+=1
                    print('if',start+1,start,int(str(tim).split(':')[0]))
                    start=int(str(tim).split(':')[0])
                else:
                    
                    list_for_lat_lon_gps=[]
                    loc_time_col=['TIME','LONG','LAT','ALT','GS']
                    for cok in loc_time_col:
                       list_for_lat_lon_gps.append(can_data.loc[start_index:count_end_index][cok].to_list())
                    countinous_count=len(can_data.loc[start_index:count_end_index])
                    rpm_con=(round((single_data_range[0][0]+single_data_range[0][1])/2)/60)*(countinous_count*5)
                    con_calculation_data.append([single_data_range[1][0],single_data_range[1][1],single_data_range[0][0],
                                                single_data_range[0][1],list_for_lat_lon_gps[0],
                                                list_for_lat_lon_gps[1],list_for_lat_lon_gps[2],list_for_lat_lon_gps[3],
                                                list_for_lat_lon_gps[4],gears_to_be_calculated_for,countinous_count,rpm_con])
                    print('tesss',can_data.loc[start_index:count_end_index]['TIME'])
                    #reset index

                    start_index=count_end_index 
                    start=int(str(tim).split(':')[0])
                    print('else',start+1,start,int(str(tim).split(':')[0]))


    for xxt in gear_wise_combo:
         count_of_time_stamp_inrange(xxt)
         
    

  for yy in gear_wise_filter:
    rotation_calculation(yy)
    break
  return calculation_data,con_calculation_data


#source_data
gear_pos_run,gear_pos_run_con=Gear_position(r'C:\Users\SARATHH\internal_data_manupulation\internal_data.csv')


#Writing_calculated_result
cal_result=pd.DataFrame(gear_pos_run,columns=['torque_y1','torque_y2','RPM_x1','RPM_x2',
                                              'Gear','Count_of_Timeframe_fall_across_tor_rpm_gear',
                                              'Formula_value'])
cal_result.to_csv('calculation_across_tor_rpm_gear.csv')


#Writing_con_calculated_result
con_cal_result=pd.DataFrame(gear_pos_run_con,columns=['torque_y1','torque_y2','RPM_x1','RPM_x2',
                                                      'TIME','LONG','LAT','ALT','GS',
                                                      'Gear','Con_Count_of_Timeframe_fall_across_tor_rpm_gear',
                                                      'Formula_value'])
con_cal_result.to_csv('continues_calculation_across_tor_rpm_gear.csv')


#torque alone revolution
torque_alone_rev=cal_result.groupby(['torque_y1','torque_y2','Gear'])['Formula_value'].agg('sum').reset_index()
torque_alone_rev['torque']=(torque_alone_rev['torque_y1']+torque_alone_rev['torque_y2'])/2
torque_alone_rev[['Gear','torque','Formula_value']].to_excel('torque_alone_revolution.xlsx')







