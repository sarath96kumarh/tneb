import pandas as pd

data_tor=pd.read_csv('tor.xlsx',error_bad_lines=False)
res=[]

for kk in data_tor['Gear']:
    res.append(data_tor[(data_tor['Gear'] == kk)].to_list())

print(res)