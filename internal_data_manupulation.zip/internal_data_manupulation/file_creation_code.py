import pandas as pd

data=pd.read_csv('internal_2.csv')
print(data['T'].head(10))