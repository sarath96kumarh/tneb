import plotly.graph_objects as go
import pandas as pd
import matplotlib.pyplot as plt 
from matplotlib.colors import ListedColormap
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import StandardScaler
from sklearn import preprocessing
# Some boilerplate to initialise things
scaler = MinMaxScaler()
scaler_1= StandardScaler()

df=pd.read_csv('delet.csv')
df[['re_speed_avg','re_rpm_avg','re_distance_total','re_fule_total','re_torque']]= scaler.fit_transform(
   df[["speed_avg", "rpm_avg",'distance_total','fule_total','torque_avg']])
visual_data=df[['mileage','re_speed_avg','re_rpm_avg','re_distance_total','re_fule_total','re_torque']]


visual_data.to_csv('normalised_data_of_max.csv')

    

cmap = ListedColormap(['#0343df', '#e50000', '#ffff14','#929591','#15B01A'])

ax = visual_data.plot.bar(x='mileage', colormap=cmap)

ax.set_xlabel(None)
ax.set_ylabel('Speed_and_distance')
ax.set_title('Mileage_obtained_across_speed_distance_torque')

plt.show()

