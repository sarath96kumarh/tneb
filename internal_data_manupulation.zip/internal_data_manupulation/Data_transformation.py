import pandas as pd
import numpy as np
from itertools import islice


speed_avg=[]
rpm_avg=[]
mileage=[]
distance=[]
fuel_total=[]
engine_torque=[]

#File Reading
data=pd.read_csv('internal_data.csv')

#Removing Outlier
cleaned_pat_data=data.loc[data['AFE']!=data['AFE'].max()]
cleaned_pat_data['AFE']=cleaned_pat_data['AFE'].astype('str')

#selecting required_data
pattern_data=cleaned_pat_data[['AFE','T','TFC','RPM','CSP','ANR','ODO']]

#removing negative Torque
pattern_data=pattern_data[pattern_data['ANR']>0].reset_index(drop=True)

#getting actually distance
pattern_data['ODO']=pattern_data['ODO']-pattern_data['ODO'][0]

#removing null records from data
ind_mileage_without_null=pattern_data.index[pattern_data['AFE']!='nan'].tolist()

#saving modified data
pattern_data['AFE']=pattern_data['AFE'].astype('float')
pattern_data.to_csv('pattern_data.csv')

final_mileage_ind=[2]
ll=[0]

#getting index for slicing
try:
    for ss in range(1,len(ind_mileage_without_null)):
        #print(ind_mileage_without_null[ss]-ind_mileage_without_null[ss+1])
        if abs(ind_mileage_without_null[ss]-ind_mileage_without_null[ss+1]) >1:
            if ll[-1]==ind_mileage_without_null[ss]:
                #final_mileage_ind.append(ind_mileage_without_null[ss])
                final_mileage_ind.append(ind_mileage_without_null[ss]+1)
            else:
                final_mileage_ind.append(ind_mileage_without_null[ss])
                final_mileage_ind.append(ind_mileage_without_null[ss]+1)
        else:
                final_mileage_ind.append(ind_mileage_without_null[ss])
                ll.append(ind_mileage_without_null[ss]+1)
except Exception:
    print('eeror')
     

final_mileage_ind=sorted(list(set(final_mileage_ind[:])-set(ll[1:])))

#print(len(final_mileage_ind[:-1]))

length_to_split=[2 for ss in range(0,round((int(len(final_mileage_ind[:-1])))/2))]

#print((len(final_mileage_ind)-1)/2)

#print(len(length_to_split))
input=iter(final_mileage_ind)
final_mileage_ind_split=[list(islice(input, elem)) for elem in length_to_split]
#print(ind_mileage_without_null[:40])
#print(ll)

speed_avg.append(pattern_data['CSP'][ind_mileage_without_null[0]])
rpm_avg.append(pattern_data['RPM'][ind_mileage_without_null[0]])
distance.append(pattern_data['ODO'][ind_mileage_without_null[0]])
mileage.append(pattern_data['AFE'][ind_mileage_without_null[0]])
fuel_total.append(pattern_data['TFC'][ind_mileage_without_null[0]])
engine_torque.append(pattern_data['ANR'][ind_mileage_without_null[0]])

#print(final_mileage_ind)
for ss in final_mileage_ind_split:
    if 11491 in ss:
        print('14681',ss,pattern_data['CSP'][ss[0]:ss[1]+1].mean()) #
    if 14710 in ss:
        print('14710',pattern_data['CSP'][ss[0]:ss[1]+1].mean())
    
    speed_avg.append(pattern_data['CSP'][ss[0]:ss[1]+1].mean())
    rpm_avg.append(pattern_data['RPM'][ss[0]:ss[1]+1].mean())
    distance.append(pattern_data['ODO'][ss[0]:ss[1]+1].sum())
    fuel_total.append(pattern_data['TFC'][ss[0]:ss[1]+1].sum())
    engine_torque.append(pattern_data['ANR'][ss[0]:ss[1]+1].mean())
    mileage.append(pattern_data['AFE'][ss[1]])
    
for kk in ll[1:]:
    speed_avg.append(pattern_data['CSP'][kk])
    mileage.append(pattern_data['AFE'][kk])
    rpm_avg.append(pattern_data['RPM'][kk])
    fuel_total.append(pattern_data['TFC'][kk])
    distance.append(pattern_data['ODO'][kk])
    engine_torque.append(pattern_data['ANR'][kk])

pattern_use=pd.DataFrame(list(zip(mileage[:],speed_avg[:],rpm_avg[:],distance[:],fuel_total[:],engine_torque[:])),columns=['mileage','speed_avg', 'rpm_avg','distance_total','fule_total','torque_avg'])
pattern_use.to_csv('consolidation_speed_avg_mileage.csv')

group=pattern_use.groupby('mileage')
maxx=group.max()
maxx.to_csv('delet.csv')
#print(final_mileage_ind_split[:5])
