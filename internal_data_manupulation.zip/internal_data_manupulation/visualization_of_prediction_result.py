import seaborn as sb
import pandas as pd
import matplotlib.pyplot as plt 
import plotly.express as px
import plotly


data=pd.read_csv('prediction_visualize.csv')
data_act=data[['speed_1', 'actual_mileage_1']]
data_act['class']='act'
data_act=data_act.rename(columns={'actual_mileage_1':'act_pre'})
data_pre=data[['speed_1','predicted_mileage_1']]
data_pre['class']='pre'
data_pre=data_pre.rename(columns={'predicted_mileage_1':'act_pre'})
frame=[data_pre,data_act]
result = pd.concat(frame)
#print(result.tail(10))
#data_2=pd.read_csv('test_x.csv')
#frame=[data,data_2]
#data_3=pd.concat(frame,axis=1)
#data_3[['speed_1','actual_mileage_1','predicted_mileage_1']]=scaler.fit_transform(data_3[['speed','actual_mileage','predicted_mileage']])
#data_3.to_csv('prediction_visualize.csv')
fig = px.scatter(result, x="speed_1", y="act_pre", marginal_y="violin",color='class',
           marginal_x="box", trendline="ols", template="simple_white")

plotly.offline.plot(fig, filename= 'plotly_plot' + ".html")
#'actual_mileage'
#'predicted_mileage'




