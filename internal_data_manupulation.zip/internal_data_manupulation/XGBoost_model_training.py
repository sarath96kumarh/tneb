import pandas as pd
from sklearn.model_selection import train_test_split
from xgboost import XGBRegressor
from sklearn.metrics import mean_absolute_error
import numpy as np
from sklearn.impute import SimpleImputer
from sklearn.metrics import explained_variance_score, r2_score, mean_absolute_error, mean_squared_error
from sklearn.metrics import accuracy_score
import seaborn as sb

imputer = SimpleImputer(missing_values=np.nan, strategy='mean')


data = pd.read_csv('consolidation_speed_avg_mileage.csv')
data=data[['mileage','speed_avg','rpm_avg','distance_total','torque_avg']]
data.dropna(axis=0, subset=['mileage'], inplace=True)


y = data.mileage
X = data.drop(['mileage'], axis=1).select_dtypes(exclude=['object'])
train_X, test_X, train_y, test_y = train_test_split(X, y, test_size=0.25)

#my_imputer = imputer()
train_X = imputer.fit_transform(train_X)
test_X = imputer.transform(test_X)

pd.DataFrame(train_X).to_csv('train_x.csv')
pd.DataFrame(test_X).to_csv('test_x.csv')


my_model = XGBRegressor(n_estimators=1000, learning_rate=0.05)
my_model.fit(train_X, train_y, early_stopping_rounds=5, 
             eval_set=[(test_X, test_y)], verbose=False)


predictions = my_model.predict(test_X)
data_result=pd.DataFrame(list(zip(test_y.to_list(),list(predictions))),columns=['actual_mileage','predicted_mileage'])
data_result.to_csv('mileage_prediction_result.csv')

#print(list(predictions),'oringinal',test_y.to_list())

variance_scores=explained_variance_score(predictions,test_y)
absolute_mean_errors=mean_absolute_error(test_y,predictions)
mean_squared_errors=mean_squared_error(test_y,predictions,squared=True)



#print('mean_square_error_of random_forest',mean_squared_errors,'random_forest_variance',
#variance_scores,'random_forest_abs_mean_error',absolute_mean_errors)

print("Mean Absolute Error : " + str(mean_absolute_error(predictions, test_y)))

