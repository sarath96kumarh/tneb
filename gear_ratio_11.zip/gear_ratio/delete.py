dict={'sarath':'aruu'}


def kkss(d):
    dict.update(d)
    

list_dict=[{'kunda_sarath':'lean_boo','mulamadri_sarath':'bubbly_boo'},{'nick_name1':'sunflower','nickname_2':'princess'}]

for ll in list_dict:
    kkss(ll)
print(dict)
