from tkinter import ttk
import tkinter as tk
from tkinter import *
import pandas as pd
import operator
from functools import reduce

#\n spliter
def split_line(val):
    if '\n' in val:
       
        source_valsplit=val.split('\n')
        return [source_valsplit[0].strip(),source_valsplit[1].strip()]
        
        
def float_line(val):
    if '\n' in val:
       
        source_valsplit=val.split('\n')
        return [float(source_valsplit[0].strip()),float(source_valsplit[1].strip())]

#data

data=pd.read_excel('./data/Master Sheet.xlsx')
configu=data['Configuration'].dropna().to_list()

#front_data
front_axel=data['Front Axle_Model'].dropna().to_list()
front_axel=reduce(operator.concat,     [split_line(ss) if '\n' in ss else [ss] for ss in front_axel])
Front_Axle_Technical=data['Front Axle_Technical capacity (Kg)'].dropna().tolist()
Front_Axle_Technical=reduce(operator.concat,     [float_line(str(ss)) if '\n' in str(ss) else [ss] for ss in Front_Axle_Technical])

zip_iterator = zip(front_axel, Front_Axle_Technical)
front_axel_dict = dict(zip_iterator)


#bacK_data
back_axel=data['Rear Axle_Model'].dropna().to_list()
back_axel=reduce(operator.concat,[split_line(ss) if '\n' in ss else [ss] for ss in back_axel])
Back_Axle_Technical=data['Rear Axle_Technical capacity (kg)'].dropna().tolist()
Back_Axle_Technical=reduce(operator.concat,     [float_line(ss) if '\n' in str(ss) else [ss] for ss in Back_Axle_Technical])
back_zip_iterator = zip(back_axel,Back_Axle_Technical)



back_axel_dict = dict(back_zip_iterator)

#tire_data
tire=data['Tires_Model'].dropna().to_list()

#Technical Capacity data

tech_cap=data['Technical Capacity (Kg)'].dropna().to_list()


#Load capacity w.r.t Speed rating

load_capacity=['110 kmph','100 kmph','90 kmph','80 kmph','70 kmph','60 kmph','50 kmph']
cap_per=[0,0,2,4,7,10,12]
load_zip=zip(load_capacity,cap_per)
load_dict=dict(load_zip)


#application

root = Tk(className='Python Examples - Window Color')
# set window size
root.geometry("1430x720")

#set window color
root.configure(bg='#1f283e')


#text box
T = Text(root, height = 5, width = 22,background='#F3EAF4',font = ("Lato,sans-serif", 14,'bold'))
T.tag_configure("tag_name", justify='center')
T.place(x=1120,y=135)


#variable
front_cho=''
rear_cho=''
first_cal_fin_res=0
sec_cal_fin_res=0
back=0
front=0
per=0


#configuration


def display_selected(choice):
    choice = text2.get()
    print(choice)

border_color = Frame(root, background="#B3A394")
ttk.Label(border_color, text = "Configuration   ",background='#F87060',foreground="white",
          font = ("Lato,sans-serif", 14,'bold')).grid( padx = 1, pady = 1)
border_color.place(x=40,y=50)





border_color_2_dd = Frame(root, background="#B3A394")
text2 = StringVar()
  
# Set the value you wish to see by default
text2.set("Choose here")
  
# Create options from the Option Menu
w = OptionMenu(border_color_2_dd, text2, *configu,command=display_selected)
  
# Se the background color of Options Menu to green
w.config(font = ("Lato,sans-serif", 14,'bold'),bg="#CFD7C7", fg="black")
  
# Set the background color of Displayed Options to Red
w["menu"].config(bg="#CFD7C7")
  
# Display the Options Menu
w.grid( padx = 1, pady = 1)
border_color_2_dd.place(x=40,y=80)



#front axel

border_color = Frame(root, background="#B3A394")
ttk.Label(border_color, text = "Front Axle Model",background='#F87060',foreground="white",
          font = ("Lato,sans-serif", 14,'bold')).grid( padx = 1, pady = 1)
border_color.place(x=370,y=50)


def display_selected_3(choice):
     global front_cho, first_cal_fin_res
     choice = text3.get()
     print(choice)
     front_cho=str(front_axel_dict[str(choice)]) 
     if rear_cho!='':
            first_cal_fin_res=int(front_cho.split('.')[0])+int(rear_cho.split('.')[0])
            
     if first_cal_fin_res and sec_cal_fin_res:
        if first_cal_fin_res<sec_cal_fin_res:
              T.delete('1.0', END)
              T.insert(tk.END,' Front and Rear axel hold less value as '+str(first_cal_fin_res)+ ' then Technical Capacity ' + str(sec_cal_fin_res))
        if sec_cal_fin_res<first_cal_fin_res:
              T.delete('1.0', END)
              T.insert(tk.END,' Technical Capacity hold less value as ' +str(sec_cal_fin_res)+' then front and rear axle '+str(first_cal_fin_res))


border_color_2_dd = Frame(root, background="#B3A394")
text3 = StringVar()
  
# Set the value you wish to see by default
text3.set("Choose here")


# Create options from the Option Menu
w = OptionMenu(border_color_2_dd, text3, *front_axel,command=display_selected_3)
  
# Se the background color of Options Menu to green
w.config(font = ("Lato,sans-serif", 14,'bold'),bg="#CFD7C7", fg="black")
  
# Set the background color of Displayed Options to Red
w["menu"].config(bg="#CFD7C7")
  
# Display the Options Menu
w.grid( padx = 1, pady = 1)
border_color_2_dd.place(x=370,y=80)



#rear Axel_model




border_color = Frame(root, background="#B3A394")
ttk.Label(border_color, text = "Rear Axle Model ",background='#F87060',foreground="white",
          font = ("Lato,sans-serif", 14,'bold')).grid( padx = 1, pady = 1)
border_color.place(x=700,y=50)



def display_selected_4(choice_r):
     global rear_cho, first_cal_fin_res
     choice_r = text4.get()
     print(choice_r)
     rear_cho=str(back_axel_dict[str(choice_r)]) 
     if front_cho!='':
            first_cal_fin_res=int(front_cho.split('.')[0])+int(rear_cho.split('.')[0])
     if first_cal_fin_res and sec_cal_fin_res:
        if first_cal_fin_res<sec_cal_fin_res:
              T.delete('1.0', END)
              T.insert(tk.END,' Front and Rear axel hold less value as '+str(first_cal_fin_res)+ ' then Technical Capacity ' + str(sec_cal_fin_res))
        if sec_cal_fin_res<first_cal_fin_res:
              T.delete('1.0', END)
              T.insert(tk.END,' Technical Capacity hold less value as ' +str(sec_cal_fin_res)+' then front and rear axle '+str(first_cal_fin_res))

border_color_2_dd = Frame(root, background="#B3A394")
text4 = StringVar()
  
# Set the value you wish to see by default
text4.set("Choose here")
  



# Create options from the Option Menu
w = OptionMenu(border_color_2_dd, text4, *back_axel,command=display_selected_4)
  
# Se the background color of Options Menu to green
w.config(font = ("Lato,sans-serif", 14,'bold'),bg="#CFD7C7", fg="black")
  
# Set the background color of Displayed Options to Red
w["menu"].config(bg="#CFD7C7")
  
# Display the Options Menu
w.grid( padx = 1, pady = 1)
border_color_2_dd.place(x=700,y=80)

print(first_cal_fin_res)

#tire

def display_selected_5(choice):
    choice = text5.get()
    print(choice)

border_color = Frame(root, background="#B3A394")
ttk.Label(border_color, text = "Tires Model     ",background='#F87060',foreground="white",
          font = ("Lato,sans-serif", 14,'bold')).grid( padx = 1, pady = 1)
border_color.place(x=40,y=250)



border_color_2_dd = Frame(root, background="#B3A394")
text5 = StringVar()
  
# Set the value you wish to see by default
text5.set("Choose here")
  
# Create options from the Option Menu
w = OptionMenu(border_color_2_dd, text5, *tire,command=display_selected_5)
  
# Se the background color of Options Menu to green
w.config(font = ("Lato,sans-serif", 14,'bold'),bg="#CFD7C7", fg="black")
  
# Set the background color of Displayed Options to Red
w["menu"].config(bg="#CFD7C7")
  
# Display the Options Menu
w.grid( padx = 1, pady = 1)
border_color_2_dd.place(x=40,y=280)



#capacity

def display_selected_6(choice_rr):
     global  sec_cal_fin_res,front,back
     choice_rr = text6.get()
     scor_lis=choice_rr.split('\n')
     front=scor_lis[0].split('-')[1]
     back=scor_lis[1].split('-')[1]
     if per:
             sec_cal_fin_res=(float(front)+float(front)*per)+(float(back)+float(back)*per)
             print(sec_cal_fin_res)
     if first_cal_fin_res and sec_cal_fin_res:
        if first_cal_fin_res<sec_cal_fin_res:
              T.delete('1.0', END)
              T.insert(tk.END,' Front and Rear axel hold less value as '+str(first_cal_fin_res)+ ' then Technical Capacity ' + str(sec_cal_fin_res))
        if sec_cal_fin_res<first_cal_fin_res:
              T.delete('1.0', END)
              T.insert(tk.END,' Technical Capacity hold less value as ' +str(sec_cal_fin_res)+' then front and rear axle '+str(first_cal_fin_res))



border_color = Frame(root, background="#B3A394")
ttk.Label(border_color, text = "Technical  Capacity",background='#F87060',foreground="white",
          font = ("Lato,sans-serif", 14,'bold')).grid( padx = 1, pady = 1)
border_color.place(x=370,y=250)



border_color_2_dd = Frame(root, background="#B3A394")
text6 = StringVar()
  
# Set the value you wish to see by default
text6.set("Choose here")
  
# Create options from the Option Menu
w = OptionMenu(border_color_2_dd, text6, *tech_cap,command=display_selected_6)
  
# Se the background color of Options Menu to green
w.config(font = ("Lato,sans-serif", 14,'bold'),bg="#CFD7C7", fg="black")
  
# Set the background color of Displayed Options to Red
w["menu"].config(bg="#CFD7C7")
  
# Display the Options Menu
w.grid( padx = 1, pady = 1)

border_color_2_dd.place(x=370,y=280)




#Load capacity w.r.t Speed rating

def display_selected_7(choice_rs):
     global  sec_cal_fin_res,per
     choice_rs = text7.get()
     per=int(load_dict[choice_rs])/100
     if front :
          sec_cal_fin_res=(float(front)+float(front)*per)+(float(back)+float(back)*per)
          print(sec_cal_fin_res)
     if first_cal_fin_res and sec_cal_fin_res:
        if first_cal_fin_res<sec_cal_fin_res:
              T.delete('1.0', END)
              T.insert(tk.END,' Front and Rear axel hold less value as '+str(first_cal_fin_res)+ ' then Technical Capacity ' + str(sec_cal_fin_res))
        if sec_cal_fin_res<first_cal_fin_res:
              T.delete('1.0', END)
              T.insert(tk.END,' Technical Capacity hold less value as ' +str(sec_cal_fin_res)+' then front and rear axle '+str(first_cal_fin_res))


border_color = Frame(root, background="#B3A394")
ttk.Label(border_color, text = "Load capacity w.r.t Speed rating",background='#F87060',foreground="white",
          font = ("Lato,sans-serif", 14,'bold')).grid( padx = 1, pady = 1)
border_color.place(x=700,y=250)



border_color_2_dd = Frame(root, background="#B3A394")
text7 = StringVar()
  
# Set the value you wish to see by default
text7.set("Choose here")
  
# Create options from the Option Menu
w = OptionMenu(border_color_2_dd, text7, *load_capacity,command=display_selected_7)
  
# Se the background color of Options Menu to green
w.config(font = ("Lato,sans-serif", 14,'bold'),bg="#CFD7C7", fg="black")
  
# Set the background color of Displayed Options to Red
w["menu"].config(bg="#CFD7C7")
  
# Display the Options Menu
w.grid( padx = 1, pady = 1)
border_color_2_dd.place(x=700,y=280)




root.mainloop() 