ss='Tire Size 10.00 R 20'
print(len(ss))

def txtt(value):
    if first_cal_fin_res<sec_cal_fin_res:
            T.insert(tk.END,value)