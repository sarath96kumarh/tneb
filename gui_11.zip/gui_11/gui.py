from tkinter import ttk
import tkinter as tk
from tkinter import *
import pandas as pd
import operator
from functools import reduce

#variable
configs=''
engine_model=''
transmission_gear=''
front_axel_1=''
front_axel_2=''
rear_axle_1=''
rear_axel_2=''
pusher_axel=''
single_tire=''
dual_tire=''
speed_limit=''
pusher_choice=''

listt_2=0
#\n spliter
def split_line(val):
    if '\n' in val:
       
        source_valsplit=val.split('\n')
        return [source_valsplit[0].strip(),source_valsplit[1].strip()]
        
        
def float_line(val):
    if '\n' in val:
       
        source_valsplit=val.split('\n')
        return [float(source_valsplit[0].strip()),float(source_valsplit[1].strip())]

#data
data=pd.read_excel('./data/data.xlsx')

#list_option
def option_list(col_name):
      #print(data[col_name])
      list_option=data[col_name].dropna().to_list()
      return list_option

#Load capacity w.r.t Speed rating data

load_capacity=['110 kmph','100 kmph','90 kmph','80 kmph','70 kmph','60 kmph','50 kmph']
cap_per=[0,0,2,4,7,10,12]
load_zip=zip(load_capacity,cap_per)
load_dict=dict(load_zip)
#print(load_dict)VBNMAS

# Dict object creation
front_axle_dict_1=''
front_axle_dict_2=''
rear_axle_dict_1=''
rear_axle_dict_2=''
psher_axel_dict=''
#tire_model_dict=''


def dict_creation(model,capacity):
      global front_axle_dict_1,front_axle_dict_2,rear_axle_dict_1,rear_axle_dict_2,psher_axel_dict,tire_model_dict
      if model!='Tires_Model':
            without_null_model=option_list(model)
            model_split=reduce(operator.concat,     [split_line(ss) if '\n' in ss else [ss] for ss in without_null_model])
            without_null_cap=option_list(capacity)
            cap_split=reduce(operator.concat,     [float_line(str(ss)) if '\n' in str(ss) else [ss] for ss in without_null_cap])
            zip_iterator = zip(model_split, cap_split)
            dcit_value = dict(zip_iterator)
            if model =='Front Axle 1_Model':
                  front_axle_dict_1=dcit_value
            if model =='Front Axle 2_Model':
                  front_axle_dict_2=dcit_value
            if model=='Rear Axle 1_Model':
                  rear_axle_dict_1=dcit_value
            if model=='Rear Axle 2_Model':
                  rear_axle_dict_2=dcit_value
            if model=='Pusher axle':
                  psher_axel_dict=dcit_value
      if model=='Tires_Model' :
            #tire_model_dict={}
            without_null_model=option_list(model)
            model_split=reduce(operator.concat,     [split_line(ss) if '\n' in ss else [ss] for ss in without_null_model])
            #without_null_Tires_Single_dual=option_list('Tires_Single/Dual')
            #single_dual_split=reduce(operator.concat,     [split_line(ss) if '\n' in ss else [ss] for ss in without_null_Tires_Single_dual])
            without_null_cap=option_list(capacity)
            cap_split=reduce(operator.concat,     [float_line(str(ss)) if '\n' in str(ss) else [ss] for ss in without_null_cap])
            #for ss in range(0,len(model_split)):
            #     tire_model_dict[model_split[ss]][single_dual_split[ss]]=cap_split[ss]
            zip_iterator = zip(model_split, cap_split)
            tire_model_dict = dict(zip_iterator)
            

model_to_def=['Front Axle 1_Model','Front Axle 2_Model','Rear Axle 1_Model','Rear Axle 2_Model','Pusher axle']
cap_to_def=['Front Axle 1_Technical capacity (Kg)','Front Axle 2_Technical capacity (Kg)','Rear Axle 1_Technical capacity (kg)','Rear Axle 2_Technical capacity (kg)','Pusher axle_Technical capacity (Kg)']
      
for mm in range(0,len(cap_to_def)):
        dict_creation(model_to_def[mm],cap_to_def[mm])

tire_model=option_list('Tires_Model')
tire_type=option_list('Tires_Single/Dual')
tire_cap=option_list('Tires_Technical Capacity (Kg)')

tire_model_type=[]

for hh in range(0,len(tire_model)):
     tire_model_type.append(tire_model[hh]+' '+tire_type[hh])

tire_model_dict= zip(tire_model_type, tire_cap)
tire_model_dict = dict(tire_model_dict)

print(rear_axle_dict_2)



#application

root = Tk(className='Python Examples - Window Color')
# set window size
root.geometry("1430x720")

#set window color
root.configure(bg='#1f283e')










def mapping (FA1=0,FA2=0,RA1=0,RA2=0,PA=0):
          global configs,w_4,w_5,w_3,w_12,w_2,front_axel_1,front_axel_2,rear_axle_1,rear_axel_2,pusher_axel
     
          if configs =='4X2':
               #print('4X2')
               w_2.configure(state='normal')
               w_3.configure(state='disabled')
               front_axel_2=''
               w_4.configure(state='normal')
               w_5.configure(state='disabled')
               rear_axel_2=''
               w_12.configure(state='disabled')
               pusher_axel=''
               #matrx=['FA1','RA1']
          if configs == '10X2' or configs=='10X4':
               w_2.configure(state='normal')
               w_3.configure(state='normal')
               w_4.configure(state='normal')
               w_5.configure(state='normal')
               w_12.configure(state='normal')
          if configs =='6X4':
               w_2.configure(state='normal')
               w_3.configure(state='disabled')
               front_axel_2=''
               w_4.configure(state='normal')
               w_5.configure(state='normal')
               w_12.configure(state='disabled')
               pusher_axel=''
          if (configs=='6X2' and  RA2==1) or (configs=='6X2' and PA==1) or (configs=='6X2' and FA1!=1) and (configs=='6X2' and RA1!=1) :
               print('test_6x2',RA2,RA1,PA,configs)
               w_2.configure(state='normal')
               w_3.configure(state='disabled')
               front_axel_2=''
               w_4.configure(state='normal')
               w_5.configure(state='normal')
               w_12.configure(state='normal')
               if RA2==1:
                    print('test22')
                    #matrx=['FA1','RA1']
                    #matrx.append('RA2')
                    w_12.configure(state='disabled')
                    pusher_axel=''
                    #w_5.configure(state='normal')
               if PA==1:
                    print('test33')
                    #matrx=['FA1','RA1']
                    #matrx.append('PA')
                    w_5.configure(state='disabled')  
                    rear_axel_2=''
                    #w_12.configure(state='normal')
          if (configs=='8X2'and FA2==1) or (configs=='8X2' and RA2==1) or configs=='8X2':
               print('coming_2',RA2,RA1,FA1,FA2,PA,configs)
               if FA1!=1 and RA1!=1 and PA!=1:
                    print('coming_2',RA2,RA1,FA1,FA2,PA,configs)
                    w_2.configure(state='normal')
                    w_3.configure(state='normal')
                    w_4.configure(state='normal')
                    w_5.configure(state='normal')
                    w_12.configure(state='normal')
               matrx=['FA1','RA1']
               if FA2==1:
                    print('coming_3')
                    #w_3.configure(state='normal')  
                    w_5.configure(state='disabled')
                    rear_axel_2=''
               if RA2==1:
                    print('coming_4')
                    w_3.configure(state='disabled')  
                    front_axel_2=''
                    #w_12.configure(state='normal')

          if configs=='8X4':
               w_2.configure(state='normal')
               w_3.configure(state='normal')
               w_4.configure(state='normal')
               w_5.configure(state='normal')
               w_12.configure(state='disabled')
               pusher_axel=''
               matrx=['FA1','FA2','RA1','RA2']
















#overall load text box

border_color_t_0 = Frame(root, background="#B3A394")
ttk.Label(border_color_t_0, text = "Overall Load Capacity",background='#F87060',foreground="white",
          font = ("Lato,sans-serif", 14,'bold')).grid( padx = 1, pady = 1)
border_color_t_0.place(x=1020,y=50)

T_over_all_load_capacity = Text(root, height = 5, width = 32,background='#F3EAF4',font = ("Lato,sans-serif", 14,'bold'))
T_over_all_load_capacity.tag_configure("tag_name", justify='center')
T_over_all_load_capacity.place(x=1020,y=80)

#axel capacity

border_color_t_1 = Frame(root, background="#B3A394")
ttk.Label(border_color_t_1, text = "Axel Capacity",background='#F87060',foreground="white",
          font = ("Lato,sans-serif", 14,'bold')).grid( padx = 1, pady = 1)
border_color_t_1.place(x=1020,y=200)

T_axel_capacity = Text(root, height = 5, width = 32,background='#F3EAF4',font = ("Lato,sans-serif", 14,'bold'))
T_axel_capacity.tag_configure("tag_name", justify='center')
T_axel_capacity.place(x=1020,y=230)



#wheel capacity

border_color_t_2 = Frame(root, background="#B3A394")
ttk.Label(border_color_t_2, text = "Wheel Capacity",background='#F87060',foreground="white",
          font = ("Lato,sans-serif", 14,'bold')).grid( padx = 1, pady = 1)
border_color_t_2.place(x=1020,y=350)

T_wheel_capacity = Text(root, height = 5, width = 32,background='#F3EAF4',font = ("Lato,sans-serif", 14,'bold'))
T_wheel_capacity.tag_configure("tag_name", justify='center')
T_wheel_capacity.place(x=1020,y=380)






#ENgine_model

border_color_0 = Frame(root, background="#B3A394")
ttk.Label(border_color_0, text = "Engine_Model",background='#F87060',foreground="white",
          font = ("Lato,sans-serif", 14,'bold')).grid( padx = 1, pady = 1)
border_color_0.place(x=40,y=150)



def display_selected_0(choice):
     global engine_model
     engine_model = text0.get()
     print(choice,engine_model)

border_color_0_dd = Frame(root, background="#B3A394")
text0 = StringVar()
  
# Set the value you wish to see by default
text0.set("Choose here")


# Create options from the Option Menu
w_0 = OptionMenu(border_color_0_dd, text0, *option_list('Engine_Model'),command=display_selected_0)
  
# Se the background color of Options Menu to green
w_0.config(font = ("Lato,sans-serif", 14,'bold'),bg="#CFD7C7", fg="black")
  
# Set the background color of Displayed Options to Red
w_0["menu"].config(bg="#CFD7C7")
  
# Display the Options Menu
w_0.grid( padx = 1, pady = 1)
border_color_0_dd.place(x=40,y=180)






#Transmission_Gear Box Model

boder_color_6 = Frame(root, background="#B3A394")
ttk.Label(boder_color_6, text = "Transmission_Gear",background='#F87060',foreground="white",
          font = ("Lato,sans-serif", 14,'bold')).grid( padx = 1, pady = 1)
boder_color_6.place(x=40,y=250)



def display_selected_6(choice):
     global transmission_gear
     transmission_gear = text6.get()
     

boder_color_6_dd = Frame(root, background="#B3A394")
text6 = StringVar()
  
# Set the value you wish to see by default
text6.set("Choose here")


# Create options from the Option Menu
w_6 = OptionMenu(boder_color_6_dd, text6, *option_list('Transmission_Gear Box Model'),command=display_selected_6)
  
# Se the background color of Options Menu to green
w_6.config(font = ("Lato,sans-serif", 14,'bold'),bg="#CFD7C7", fg="black")
  
# Set the background color of Displayed Options to Red
w_6["menu"].config(bg="#CFD7C7")
  
# Display the Options Menu
w_6.grid( padx = 1, pady = 1)
boder_color_6_dd.place(x=40,y=280)








#Front Axle 1_Model


def display_selected(choice):
    global front_axel_1
    #dict_creation('Front Axle 1_Model','Front Axle 1_Technical capacity (Kg)')
    print(text2.get(),'.........')
    front_axel_1 = front_axle_dict_1[text2.get()]
    mapping(FA1=1)
    
    

border_color = Frame(root, background="#B3A394")
ttk.Label(border_color, text = "Front Axle 1_Model",background='#F87060',foreground="white",
          font = ("Lato,sans-serif", 14,'bold')).grid( padx = 1, pady = 1)
border_color.place(x=300,y=50)





border_color_2_dd = Frame(root, background="#B3A394")
text2 = StringVar()
  
# Set the value you wish to see by default
text2.set("Choose here")
  
# Create options from the Option Menu
w_2 = OptionMenu(border_color_2_dd, text2, *option_list('Front Axle 1_Model'),command=display_selected)
  
# Se the background color of Options Menu to green
w_2.config(font = ("Lato,sans-serif", 14,'bold'),bg="#CFD7C7", fg="black")
  
# Set the background color of Displayed Options to Red
w_2["menu"].config(bg="#CFD7C7")
  
# Display the Options Menu
w_2.grid( padx = 1, pady = 1)
border_color_2_dd.place(x=300,y=80)


#Front Axle 2_Model

border_color_3 = Frame(root, background="#B3A394")
ttk.Label(border_color_3, text = "Front Axle 2_Model",background='#F87060',foreground="white",
          font = ("Lato,sans-serif", 14,'bold')).grid( padx = 1, pady = 1)
border_color_3.place(x=300,y=150)



def display_selected_3(choice):
     global front_axel_2
     #dict_creation('Front Axle 2_Model','Front Axle 2_Technical capacity (Kg)')
     front_axel_2 = front_axle_dict_2[text3.get()]
     mapping(FA2=1)

border_color_3_dd = Frame(root, background="#B3A394")
text3 = StringVar()
  
# Set the value you wish to see by default
text3.set("Choose here")


# Create options from the Option Menu
w_3 = OptionMenu(border_color_3_dd, text3, *option_list('Front Axle 2_Model'),command=display_selected_3)

# Se the background color of Options Menu to green
w_3.config(font = ("Lato,sans-serif", 14,'bold'),bg="#CFD7C7", fg="black")
  
# Set the background color of Displayed Options to Red
w_3["menu"].config(bg="#CFD7C7")
  
# Display the Options Menu
w_3.grid( padx = 1, pady = 1)
border_color_3_dd.place(x=300,y=180)





# Rear Axle 1_Model


boder_color_4 = Frame(root, background="#B3A394")
ttk.Label(boder_color_4, text = "Rear Axle 1_Model",background='#F87060',foreground="white",
          font = ("Lato,sans-serif", 14,'bold')).grid( padx = 1, pady = 1)
boder_color_4.place(x=300,y=250)



def display_selected_3(choice):
     global rear_axle_1
     #dict_creation('Rear Axle 1_Model','Rear Axle 1_Technical capacity (Kg)')
     rear_axle_1 = rear_axle_dict_1[text4.get()]
     mapping(RA1=1)

boder_color_4_dd = Frame(root, background="#B3A394")
text4 = StringVar()
  
# Set the value you wish to see by default
text4.set("Choose here")


# Create options from the Option Menu
w_4 = OptionMenu(boder_color_4_dd, text4, *option_list('Rear Axle 1_Model'),command=display_selected_3)
  
# Se the background color of Options Menu to green
w_4.config(font = ("Lato,sans-serif", 14,'bold'),bg="#CFD7C7", fg="black")
  
# Set the background color of Displayed Options to Red
w_4["menu"].config(bg="#CFD7C7")
  
# Display the Options Menu
w_4.grid( padx = 1, pady = 1)
boder_color_4_dd.place(x=300,y=280)






#Rear Axle 2_Model

boder_color_5 = Frame(root, background="#B3A394")
ttk.Label(boder_color_5, text = "Rear Axle 2_Model",background='#F87060',foreground="white",
          font = ("Lato,sans-serif", 14,'bold')).grid( padx = 1, pady = 1)
boder_color_5.place(x=300,y=350)



def display_selected_3(choice):
     global rear_axel_2
     #dict_creation('Rear Axle 2_Model','Rear Axle 2_Technical capacity (Kg)')
     rear_axel_2 = rear_axle_dict_2[text5.get()]
     mapping(RA2=1)

boder_color_5_dd = Frame(root, background="#B3A394")
text5 = StringVar()
  
# Set the value you wish to see by default
text5.set("Choose here")


# Create options from the Option Menu
w_5 = OptionMenu(boder_color_5_dd, text5, *option_list('Rear Axle 2_Model'),command=display_selected_3)

# Se the background color of Options Menu to green
w_5.config(font = ("Lato,sans-serif", 14,'bold'),bg="#CFD7C7", fg="black")
  
# Set the background color of Displayed Options to Red
w_5["menu"].config(bg="#CFD7C7")
  
# Display the Options Menu
w_5.grid( padx = 1, pady = 1)
boder_color_5_dd.place(x=300,y=380)



        



















#Pusher axle

boder_color_12 = Frame(root, background="#B3A394")
ttk.Label(boder_color_12, text = "Pusher axle",background='#F87060',foreground="white",
          font = ("Lato,sans-serif", 14,'bold')).grid( padx = 1, pady = 1)
boder_color_12.place(x=300,y=450)



def display_selected_12(choice):
     global pusher_axel,pusher_choice
     pusher_choice=choice
     #dict_creation('Pusher axle','Pusher axle_Technical capacity (Kg)')
     pusher_axel= psher_axel_dict[text12.get()]
     mapping(PA=1)

boder_color_12_dd = Frame(root, background="#B3A394")
text12 = StringVar()
  
# Set the value you wish to see by default
text12.set("Choose here")


# Create options from the Option Menu
w_12 = OptionMenu(boder_color_12_dd, text12, *option_list('Pusher axle'),command=display_selected_12)

# Se the background color of Options Menu to green
w_12.config(font = ("Lato,sans-serif", 14,'bold'),bg="#CFD7C7", fg="black")
  
# Set the background color of Displayed Options to Red
w_12["menu"].config(bg="#CFD7C7")
  
# Display the Options Menu
w_12.grid( padx = 1, pady = 1)
boder_color_12_dd.place(x=300,y=480)



#single trie model

boder_color_7 = Frame(root, background="#B3A394")
ttk.Label(boder_color_7, text = "Single Tires Model",background='#F87060',foreground="white",
          font = ("Lato,sans-serif", 14,'bold')).grid( padx = 1, pady = 1)
boder_color_7.place(x=660,y=50)



def display_selected_7(choice):
     global single_tire
     #dict_creation('Tires_Model','Tires_Technical Capacity (Kg)',type='single')
     single_tire = tire_model_dict[text7.get()+' '+'Single Tyre']
     

boder_color_7_dd = Frame(root, background="#B3A394")
text7 = StringVar()
  
# Set the value you wish to see by default
text7.set("Choose here")


# Create options from the Option Menu
w_7 = OptionMenu(boder_color_7_dd, text7, *set(option_list('Tires_Model')),command=display_selected_7)
  
# Se the background color of Options Menu to green
w_7.config(font = ("Lato,sans-serif", 14,'bold'),bg="#CFD7C7", fg="black")
  
# Set the background color of Displayed Options to Red
w_7["menu"].config(bg="#CFD7C7")
  
# Display the Options Menu
w_7.grid( padx = 1, pady = 1)
boder_color_7_dd.place(x=660,y=80)


#dual tires
boder_color_8 = Frame(root, background="#B3A394")
ttk.Label(boder_color_8, text = "Dual Tires Model",background='#F87060',foreground="white",
          font = ("Lato,sans-serif", 14,'bold')).grid( padx = 1, pady = 1)
boder_color_8.place(x=660,y=150)



def display_selected_8(choice):
     global dual_tire
     #dict_creation('Tires_Model','Tires_Technical Capacity (Kg)',type='dual')
     dual_tire= tire_model_dict[text8.get()+' '+'Dual Tyre']
     

boder_color_8_dd = Frame(root, background="#B3A394")
text8 = StringVar()
  
# Set the value you wish to see by default
text8.set("Choose here")


# Create options from the Option Menu
w_8 = OptionMenu(boder_color_8_dd, text8, *set(option_list('Tires_Model')),command=display_selected_8)
  
# Se the background color of Options Menu to green
w_8.config(font = ("Lato,sans-serif", 14,'bold'),bg="#CFD7C7", fg="black")
  
# Set the background color of Displayed Options to Red
w_8["menu"].config(bg="#CFD7C7")
  
# Display the Options Menu
w_8.grid( padx = 1, pady = 1)
boder_color_8_dd.place(x=660,y=180)



#Load capacity w.r.t Speed rating

def display_selected_9(choice_rs):
     global  speed_limit
     speed_limit = load_dict[text9.get()]

border_color_9 = Frame(root, background="#B3A394")
ttk.Label(border_color_9, text = "w.r.t Speed rating",background='#F87060',foreground="white",
        font = ("Lato,sans-serif", 14,'bold')).grid( padx = 1, pady = 1)
border_color_9.place(x=660,y=250)



border_color_9_dd = Frame(root, background="#B3A394")
text9 = StringVar()

# Set the value you wish to see by default
text9.set("Choose here")

# Create options from the Option Menu
w_9 = OptionMenu(border_color_9_dd, text9, *load_capacity,command=display_selected_9)

# Se the background color of Options Menu to green
w_9.config(font = ("Lato,sans-serif", 14,'bold'),bg="#CFD7C7", fg="black")

# Set the background color of Displayed Options to Red
w_9["menu"].config(bg="#CFD7C7")

# Display the Options Menu
w_9.grid( padx = 1, pady = 1)
border_color_9_dd.place(x=660,y=280)




     

#configuration


def display_selected(choice):
     global configs,w_4,w_5,listt_2,boder_color_5,boder_color_4,boder_color_5_dd,boder_color_4_dd
     choice = text_con.get()
     configs=choice
     mapping()
     if configs=='4X2':
          ra11_op=['MS 145 - 12 thk','MS 145 - 13 thk','DANA S145 - 12 thk','IR440-11']
          ra22_op=option_list('Rear Axle 2_Model')
     if configs=='6X2' or configs=='8X2' or configs=='10X2':
          ra11_op=['MS 145 - 12 thk','MS 145 - 13 thk','DANA S145 - 12 thk','IR440-11']
          ra22_op=['TAG Axle IT-10','Tag axle IT-14']
     if configs=='6X4' or configs=='8X4':
          ra11_op=['IRT 390-11','MT36 610']
          ra22_op=['IRT 390-11','MT36 610']
     if configs=='10X4':
          ra11_op=option_list('Rear Axle 1_Model')
          ra22_op=option_list('Rear Axle 2_Model')
    
     # Rear Axle 1_Model
     
     def display_selected_3(choice):
          global front_cho, first_cal_fin_res
          choice = text5.get()
          mapping(RA2=1)
     #print(w_5,w_4)
     if w_5 and configs!='4X2':
          #print('.......,',configs,type(configs))
          w_5.destroy()
          boder_color_5.destroy()
          boder_color_5_dd.destroy()
          boder_color_5 = Frame(root, background="#B3A394")
          ttk.Label(boder_color_5, text = "Rear Axle 2_Model",background='#F87060',foreground="white",
                    font = ("Lato,sans-serif", 14,'bold')).grid( padx = 1, pady = 1)
          boder_color_5.place(x=300,y=350)



          def display_selected_3(choice):
               global rear_axel_2
               #dict_creation('Rear Axle 2_Model','Rear Axle 2_Technical capacity (Kg)')
               rear_axel_2 = rear_axle_dict_2[text5.get()]
               mapping(RA2=1)

          boder_color_5_dd = Frame(root, background="#B3A394")
          text5 = StringVar()
          
          # Set the value you wish to see by default
          text5.set("Choose here")


          # Create options from the Option Menu
          w_5 = OptionMenu(boder_color_5_dd, text5, *ra22_op,command=display_selected_3)

          # Se the background color of Options Menu to green
          w_5.config(font = ("Lato,sans-serif", 14,'bold'),bg="#CFD7C7", fg="black")
          
          # Set the background color of Displayed Options to Red
          w_5["menu"].config(bg="#CFD7C7")
          
          # Display the Options Menu
          w_5.grid( padx = 1, pady = 1)
          boder_color_5_dd.place(x=300,y=380)

     if w_4:
          w_4.destroy()
          boder_color_4.destroy()
          boder_color_4_dd.destroy()
          
          boder_color_4 = Frame(root, background="#B3A394")
          ttk.Label(boder_color_4, text = "Rear Axle 1_Model",background='#F87060',foreground="white",
                    font = ("Lato,sans-serif", 14,'bold')).grid( padx = 1, pady = 1)
          boder_color_4.place(x=300,y=250)



          def display_selected_3(choice):
               global rear_axle_1
               #dict_creation('Rear Axle 1_Model','Rear Axle 1_Technical capacity (Kg)')
               rear_axle_1 = rear_axle_dict_1[text4.get()]
               mapping(RA1=1)

          boder_color_4_dd = Frame(root, background="#B3A394")
          text4 = StringVar()
          
          # Set the value you wish to see by default
          text4.set("Choose here")


          # Create options from the Option Menu
          w_4 = OptionMenu(boder_color_4_dd, text4, *ra11_op,command=display_selected_3)
          
          # Se the background color of Options Menu to green
          w_4.config(font = ("Lato,sans-serif", 14,'bold'),bg="#CFD7C7", fg="black")
          
          # Set the background color of Displayed Options to Red
          w_4["menu"].config(bg="#CFD7C7")
          
          # Display the Options Menu
          w_4.grid( padx = 1, pady = 1)
          boder_color_4_dd.place(x=300,y=280)




     

 

     
     


border_color = Frame(root, background="#B3A394")
ttk.Label(border_color, text = "Configuration   ",background='#F87060',foreground="white",
          font = ("Lato,sans-serif", 14,'bold')).grid( padx = 1, pady = 1)
border_color.place(x=40,y=50)





border_color_2_dd = Frame(root, background="#B3A394")
text_con = StringVar()
  
# Set the value you wish to see by default
text_con.set("Choose here")
  
# Create options from the Option Menu
w = OptionMenu(border_color_2_dd, text_con, *option_list('Configuration'),command=display_selected)
  
# Se the background color of Options Menu to green
w.config(font = ("Lato,sans-serif", 14,'bold'),bg="#CFD7C7", fg="black")
  
# Set the background color of Displayed Options to Red
w["menu"].config(bg="#CFD7C7")
  
# Display the Options Menu
w.grid( padx = 1, pady = 1)
border_color_2_dd.place(x=40,y=80)













border_color_sub_dd = Frame(root, background="#C0C781")

def submit_operation():
   global front_axel_1,front_axel_2,rear_axle_1,rear_axel_2,pusher_axel,single_tire,dual_tire,speed_limit,pusher_choice,push_1
   front_1=0
   front_2=0
   back_1=0
   back_2=0
   push_1=0
   if configs=='4X2':
        if front_axel_1!='' and rear_axle_1!='' and single_tire!='' and dual_tire!='' and speed_limit!='':
             print(front_axel_1)
             
             front_axel_1=int(str(front_axel_1).split('.')[0])
             rear_axle_1=int(str(rear_axle_1).split('.')[0])
             single_tire_cal_value=(int(str(single_tire).split('.')[0])+((int(str(single_tire).split('.')[0]))*((speed_limit/100))))*2
             dual_tire_cal_value=(int(str(dual_tire).split('.')[0])+((int(str(dual_tire).split('.')[0]))*((speed_limit/100))))*4
             print(single_tire_cal_value,dual_tire_cal_value,dual_tire,'tire')
             print(front_axel_1,rear_axle_1,'axel')
             if front_axel_1>single_tire_cal_value:
                  front_1=front_axel_1
             else:
                  front_1=single_tire_cal_value
             if rear_axle_1>dual_tire_cal_value:
                  back_1=rear_axle_1
             else:
                  back_1=dual_tire_cal_value
             T_over_all_load_capacity.delete('1.0', END)
             T_over_all_load_capacity.insert(tk.END,str(front_1+back_1))
             T_axel_capacity.delete('1.0', END)
             T_axel_capacity.insert(tk.END,str(front_axel_1+rear_axle_1))
             T_wheel_capacity.delete('1.0', END)
             T_wheel_capacity.insert(tk.END,str(single_tire_cal_value+dual_tire_cal_value))

   if configs=='6X2':
       last_6X2='' 
       if front_axel_1!='' and rear_axle_1!='' and rear_axel_2!=''  and single_tire!='' and dual_tire!='' and speed_limit!='':
             
             front_axel_1=int(str(front_axel_1).split('.')[0])
             rear_axle_1=int(str(rear_axle_1).split('.')[0])
             rear_axel_2=int(str(rear_axel_2).split('.')[0])
             single_tire_cal_value=(int(str(single_tire).split('.')[0])+((int(str(single_tire).split('.')[0]))*((speed_limit/100))))*2
             dual_tire_cal_value=(int(str(dual_tire).split('.')[0])+((int(str(dual_tire).split('.')[0]))*((speed_limit/100))))*4
             print(single_tire_cal_value,dual_tire_cal_value,dual_tire,'tire_rear')
             print(front_axel_1,rear_axle_1,'axel_rear')
             if front_axel_1>single_tire_cal_value:
                  front_1=front_axel_1
             else:
                  front_1=single_tire_cal_value

             if rear_axle_1>dual_tire_cal_value:
                   back_1=rear_axle_1
             else:
                  back_1=dual_tire_cal_value

             if rear_axel_2>dual_tire_cal_value:
                  back_2=rear_axel_2
             else:
                  back_2=dual_tire_cal_value 

             T_over_all_load_capacity.delete('1.0', END)
             T_over_all_load_capacity.insert(tk.END,str(front_1+back_1+back_2))
             T_axel_capacity.delete('1.0', END)
             T_axel_capacity.insert(tk.END,str(front_axel_1+rear_axle_1+rear_axel_2))
             T_wheel_capacity.delete('1.0', END)
             T_wheel_capacity.insert(tk.END,str(single_tire_cal_value+dual_tire_cal_value+dual_tire_cal_value))

       if front_axel_1!='' and rear_axle_1!=''  and pusher_axel!='' and single_tire!='' and dual_tire!='' and speed_limit!='':
             front_axel_1=int(str(front_axel_1).split('.')[0])
             rear_axle_1=int(str(rear_axle_1).split('.')[0])
             pusher_axel=int(str(pusher_axel).split('.')[0])
             single_tire_cal_value=(int(str(single_tire).split('.')[0])+((int(str(single_tire).split('.')[0]))*((speed_limit/100))))*2
             dual_tire_cal_value=(int(str(dual_tire).split('.')[0])+((int(str(dual_tire).split('.')[0]))*((speed_limit/100))))*4
             print(single_tire_cal_value,dual_tire_cal_value,dual_tire,'tire_push')
             print(front_axel_1,rear_axle_1,'axel_push')
             if front_axel_1>single_tire_cal_value:
                  front_1=front_axel_1
             else:
                  front_1=single_tire_cal_value

             if rear_axle_1>dual_tire_cal_value:
                   back_1=rear_axle_1
             else:
                  back_1=dual_tire_cal_value
             
             if pusher_choice=='Lift axle VD4- 7.0':
                last_6X2=single_tire_cal_value
                if pusher_axel>single_tire_cal_value:
                         push_1=pusher_axel
                else:
                         push_1=single_tire_cal_value
             
             if pusher_choice=='Twin Tyre Pusher Axle':
                last_6X2=dual_tire_cal_value
                if pusher_axel>dual_tire_cal_value:
                         push_1=pusher_axel
                else:
                         push_1=dual_tire_cal_value

             T_over_all_load_capacity.delete('1.0', END)
             T_over_all_load_capacity.insert(tk.END,str(front_1+back_1+push_1))
             T_axel_capacity.delete('1.0', END)
             T_axel_capacity.insert(tk.END,str(front_axel_1+rear_axle_1+pusher_axel))
             T_wheel_capacity.delete('1.0', END)
             T_wheel_capacity.insert(tk.END,str(single_tire_cal_value+dual_tire_cal_value+last_6X2)) 

   if configs=='6X4':
        if front_axel_1!='' and rear_axle_1!='' and rear_axel_2!=''  and single_tire!='' and dual_tire!='' and speed_limit!='':
             
             front_axel_1=int(str(front_axel_1).split('.')[0])
             rear_axle_1=int(str(rear_axle_1).split('.')[0])
             rear_axel_2=int(str(rear_axel_2).split('.')[0])
             single_tire_cal_value=(int(str(single_tire).split('.')[0])+((int(str(single_tire).split('.')[0]))*((speed_limit/100))))*2
             dual_tire_cal_value=(int(str(dual_tire).split('.')[0])+((int(str(dual_tire).split('.')[0]))*((speed_limit/100))))*4
             print(single_tire_cal_value,dual_tire_cal_value,dual_tire,'tire_rear')
             print(front_axel_1,rear_axle_1,'axel_rear')
             if front_axel_1>single_tire_cal_value:
                  front_1=front_axel_1
             else:
                  front_1=single_tire_cal_value

             if rear_axle_1>dual_tire_cal_value:
                   back_1=rear_axle_1
             else:
                  back_1=dual_tire_cal_value

             if rear_axel_2>dual_tire_cal_value:
                  back_2=rear_axel_2
             else:
                  back_2=dual_tire_cal_value 

             T_over_all_load_capacity.delete('1.0', END)
             T_over_all_load_capacity.insert(tk.END,str(front_1+back_1+back_2))
             T_axel_capacity.delete('1.0', END)
             T_axel_capacity.insert(tk.END,str(front_axel_1+rear_axle_1+rear_axel_2))
             T_wheel_capacity.delete('1.0', END)
             T_wheel_capacity.insert(tk.END,str(single_tire_cal_value+dual_tire_cal_value+dual_tire_cal_value))
   
   if configs=='8X2':
          if front_axel_1!='' and front_axel_2!='' and rear_axle_1!=''  and pusher_axel!='' and single_tire!='' and dual_tire!='' and speed_limit!='':
             front_axel_1=int(str(front_axel_1).split('.')[0])
             front_axel_2=int(str(front_axel_2).split('.')[0])
             rear_axle_1=int(str(rear_axle_1).split('.')[0])
             pusher_axel=int(str(pusher_axel).split('.')[0])
             single_tire_cal_value=(int(str(single_tire).split('.')[0])+((int(str(single_tire).split('.')[0]))*((speed_limit/100))))*2
             dual_tire_cal_value=(int(str(dual_tire).split('.')[0])+((int(str(dual_tire).split('.')[0]))*((speed_limit/100))))*4
             print(single_tire_cal_value,dual_tire_cal_value,dual_tire,'tire_push')
             print(front_axel_1,rear_axle_1,'axel_push')
             if front_axel_1>single_tire_cal_value:
                  front_1=front_axel_1
             else:
                  front_1=single_tire_cal_value
             
             if front_axel_2>single_tire_cal_value:
                  front_2=front_axel_2
             else:
                  front_2=single_tire_cal_value


             if rear_axle_1>dual_tire_cal_value:
                   back_1=rear_axle_1
             else:
                  back_1=dual_tire_cal_value
             
             if pusher_choice=='Lift axle VD4- 7.0':
                last_6X2=single_tire_cal_value
                if pusher_axel>single_tire_cal_value:
                         push_1=pusher_axel
                else:
                         push_1=single_tire_cal_value
             
             if pusher_choice=='Twin Tyre Pusher Axle':
                last_6X2=dual_tire_cal_value
                if pusher_axel>dual_tire_cal_value:
                         push_1=pusher_axel
                else:
                         push_1=dual_tire_cal_value

             T_over_all_load_capacity.delete('1.0', END)
             T_over_all_load_capacity.insert(tk.END,str(front_1+front_2+back_1+push_1))
             T_axel_capacity.delete('1.0', END)
             T_axel_capacity.insert(tk.END,str(front_axel_1+front_axel_2+rear_axle_1+pusher_axel))
             T_wheel_capacity.delete('1.0', END)
             T_wheel_capacity.insert(tk.END,str(single_tire_cal_value+single_tire_cal_value+dual_tire_cal_value+last_6X2)) 


          if front_axel_1!='' and  rear_axle_1!='' and rear_axel_2!=''  and pusher_axel!='' and single_tire!='' and dual_tire!='' and speed_limit!='':
             front_axel_1=int(str(front_axel_1).split('.')[0])
             rear_axle_1=int(str(rear_axle_1).split('.')[0])
             rear_axel_2=int(str(rear_axel_2).split('.')[0])
             pusher_axel=int(str(pusher_axel).split('.')[0])
             single_tire_cal_value=(int(str(single_tire).split('.')[0])+((int(str(single_tire).split('.')[0]))*((speed_limit/100))))*2
             dual_tire_cal_value=(int(str(dual_tire).split('.')[0])+((int(str(dual_tire).split('.')[0]))*((speed_limit/100))))*4
             print(single_tire_cal_value,dual_tire_cal_value,dual_tire,'tire_push')
             print(front_axel_1,rear_axle_1,'axel_push')
             if front_axel_1>single_tire_cal_value:
                  front_1=front_axel_1
             else:
                  front_1=single_tire_cal_value
             
             
             if rear_axle_1>dual_tire_cal_value:
                   back_1=rear_axle_1
             else:
                  back_1=dual_tire_cal_value
             
             if rear_axel_2>dual_tire_cal_value:
                   back_2=rear_axel_2
             else:
                  back_2=dual_tire_cal_value

             if pusher_choice=='Lift axle VD4- 7.0':
                last_6X2=single_tire_cal_value
                if pusher_axel>single_tire_cal_value:
                         push_1=pusher_axel
                else:
                         push_1=single_tire_cal_value
             
             if pusher_choice=='Twin Tyre Pusher Axle':
                last_6X2=dual_tire_cal_value
                if pusher_axel>dual_tire_cal_value:
                         push_1=pusher_axel
                else:
                         push_1=dual_tire_cal_value

             T_over_all_load_capacity.delete('1.0', END)
             T_over_all_load_capacity.insert(tk.END,str(front_1+back_1+back_2+push_1))
             T_axel_capacity.delete('1.0', END)
             T_axel_capacity.insert(tk.END,str(front_axel_1+rear_axle_1+rear_axel_2+pusher_axel))
             T_wheel_capacity.delete('1.0', END)
             T_wheel_capacity.insert(tk.END,str(single_tire_cal_value+dual_tire_cal_value+dual_tire_cal_value+last_6X2)) 

   if configs=='8X4':
         if front_axel_1!='' and front_axel_2 !=''and rear_axle_1!='' and rear_axel_2!='' and single_tire!='' and dual_tire!='' and speed_limit!='':
             front_axel_1=int(str(front_axel_1).split('.')[0])
             front_axel_2=int(str(front_axel_2).split('.')[0])
             rear_axle_1=int(str(rear_axle_1).split('.')[0])
             rear_axel_2=int(str(rear_axel_2).split('.')[0])
             #pusher_axel=int(str(pusher_axel).split('.')[0])
             single_tire_cal_value=(int(str(single_tire).split('.')[0])+((int(str(single_tire).split('.')[0]))*((speed_limit/100))))*2
             dual_tire_cal_value=(int(str(dual_tire).split('.')[0])+((int(str(dual_tire).split('.')[0]))*((speed_limit/100))))*4
             print(single_tire_cal_value,dual_tire_cal_value,dual_tire,'tire_push')
             print(front_axel_1,rear_axle_1,'axel_push')
             if front_axel_1>single_tire_cal_value:
                  front_1=front_axel_1
             else:
                  front_1=single_tire_cal_value
             
             if front_axel_2>single_tire_cal_value:
                  front_2=front_axel_2
             else:
                  front_2=single_tire_cal_value

             if rear_axle_1>dual_tire_cal_value:
                   back_1=rear_axle_1
             else:
                  back_1=dual_tire_cal_value
             
             if rear_axel_2>dual_tire_cal_value:
                   back_2=rear_axel_2
             else:
                  back_2=dual_tire_cal_value

             

             T_over_all_load_capacity.delete('1.0', END)
             T_over_all_load_capacity.insert(tk.END,str(front_1+front_2+back_1+back_2))
             T_axel_capacity.delete('1.0', END)
             T_axel_capacity.insert(tk.END,str(front_axel_1+front_axel_2+rear_axle_1+rear_axel_2))
             T_wheel_capacity.delete('1.0', END)
             T_wheel_capacity.insert(tk.END,str(single_tire_cal_value+single_tire_cal_value+dual_tire_cal_value+dual_tire_cal_value)) 
   if configs=='10X2' or configs=='10X4':
        if front_axel_1!='' and front_axel_2 !=''and rear_axle_1!='' and rear_axel_2!='' and pusher_axel!='' and single_tire!='' and dual_tire!='' and speed_limit!='':
             front_axel_1=int(str(front_axel_1).split('.')[0])
             front_axel_2=int(str(front_axel_2).split('.')[0])
             rear_axle_1=int(str(rear_axle_1).split('.')[0])
             rear_axel_2=int(str(rear_axel_2).split('.')[0])
             pusher_axel=int(str(pusher_axel).split('.')[0])
             single_tire_cal_value=(int(str(single_tire).split('.')[0])+((int(str(single_tire).split('.')[0]))*((speed_limit/100))))*2
             dual_tire_cal_value=(int(str(dual_tire).split('.')[0])+((int(str(dual_tire).split('.')[0]))*((speed_limit/100))))*4
             print(single_tire_cal_value,dual_tire_cal_value,dual_tire,'tire_push')
             print(front_axel_1,rear_axle_1,'axel_push')
             if front_axel_1>single_tire_cal_value:
                  front_1=front_axel_1
             else:
                  front_1=single_tire_cal_value
             
             if front_axel_2>single_tire_cal_value:
                  front_2=front_axel_2
             else:
                  front_2=single_tire_cal_value

             if rear_axle_1>dual_tire_cal_value:
                   back_1=rear_axle_1
             else:
                  back_1=dual_tire_cal_value
             
             if rear_axel_2>dual_tire_cal_value:
                   back_2=rear_axel_2
             else:
                  back_2=dual_tire_cal_value
             
             if pusher_choice=='Lift axle VD4- 7.0':
                last_6X2=single_tire_cal_value
                if pusher_axel>single_tire_cal_value:
                         push_1=pusher_axel
                else:
                         push_1=single_tire_cal_value
             
             if pusher_choice=='Twin Tyre Pusher Axle':
                last_6X2=dual_tire_cal_value
                if pusher_axel>dual_tire_cal_value:
                         push_1=pusher_axel
                else:
                         push_1=dual_tire_cal_value
             

             T_over_all_load_capacity.delete('1.0', END)
             T_over_all_load_capacity.insert(tk.END,str(front_1+front_2+back_1+back_2+push_1))
             T_axel_capacity.delete('1.0', END)
             T_axel_capacity.insert(tk.END,str(front_axel_1+front_axel_2+rear_axle_1+rear_axel_2+pusher_axel))
             T_wheel_capacity.delete('1.0', END)
             T_wheel_capacity.insert(tk.END,str(single_tire_cal_value+single_tire_cal_value+dual_tire_cal_value+dual_tire_cal_value+last_6X2)) 

B = Button(border_color_sub_dd, text ="SUBMIT", command = submit_operation)
B.config(font = ("Lato,sans-serif", 14,'bold'),bg="#78BC61", fg="black")
B.grid( padx = 1, pady = 1)
border_color_sub_dd.place(x=660,y=350)


root.mainloop() 
