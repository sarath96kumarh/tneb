from tkinter import ttk
import tkinter as tk
from tkinter import *
import pandas as pd
import operator
from functools import reduce


engine_data=pd.read_excel('Engine_Sample.xlsx')
print(engine_data.head(10))